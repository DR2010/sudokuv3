namespace SudokuClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.input_00_00 = new System.Windows.Forms.TextBox();
            this.input_00_01 = new System.Windows.Forms.TextBox();
            this.input_00_02 = new System.Windows.Forms.TextBox();
            this.input_00_03 = new System.Windows.Forms.TextBox();
            this.input_00_04 = new System.Windows.Forms.TextBox();
            this.input_00_05 = new System.Windows.Forms.TextBox();
            this.input_00_06 = new System.Windows.Forms.TextBox();
            this.input_00_07 = new System.Windows.Forms.TextBox();
            this.input_00_08 = new System.Windows.Forms.TextBox();
            this.input_01_08 = new System.Windows.Forms.TextBox();
            this.input_01_07 = new System.Windows.Forms.TextBox();
            this.input_01_06 = new System.Windows.Forms.TextBox();
            this.input_01_05 = new System.Windows.Forms.TextBox();
            this.input_01_04 = new System.Windows.Forms.TextBox();
            this.input_01_03 = new System.Windows.Forms.TextBox();
            this.input_01_02 = new System.Windows.Forms.TextBox();
            this.input_01_01 = new System.Windows.Forms.TextBox();
            this.input_01_00 = new System.Windows.Forms.TextBox();
            this.input_02_08 = new System.Windows.Forms.TextBox();
            this.input_02_07 = new System.Windows.Forms.TextBox();
            this.input_02_06 = new System.Windows.Forms.TextBox();
            this.input_02_05 = new System.Windows.Forms.TextBox();
            this.input_02_04 = new System.Windows.Forms.TextBox();
            this.input_02_03 = new System.Windows.Forms.TextBox();
            this.input_02_02 = new System.Windows.Forms.TextBox();
            this.input_02_01 = new System.Windows.Forms.TextBox();
            this.input_02_00 = new System.Windows.Forms.TextBox();
            this.input_03_08 = new System.Windows.Forms.TextBox();
            this.input_03_07 = new System.Windows.Forms.TextBox();
            this.input_03_06 = new System.Windows.Forms.TextBox();
            this.input_03_05 = new System.Windows.Forms.TextBox();
            this.input_03_04 = new System.Windows.Forms.TextBox();
            this.input_03_03 = new System.Windows.Forms.TextBox();
            this.input_03_02 = new System.Windows.Forms.TextBox();
            this.input_03_01 = new System.Windows.Forms.TextBox();
            this.input_03_00 = new System.Windows.Forms.TextBox();
            this.input_04_08 = new System.Windows.Forms.TextBox();
            this.input_04_07 = new System.Windows.Forms.TextBox();
            this.input_04_06 = new System.Windows.Forms.TextBox();
            this.input_04_05 = new System.Windows.Forms.TextBox();
            this.input_04_04 = new System.Windows.Forms.TextBox();
            this.input_04_03 = new System.Windows.Forms.TextBox();
            this.input_04_02 = new System.Windows.Forms.TextBox();
            this.input_04_01 = new System.Windows.Forms.TextBox();
            this.input_04_00 = new System.Windows.Forms.TextBox();
            this.input_07_08 = new System.Windows.Forms.TextBox();
            this.input_07_07 = new System.Windows.Forms.TextBox();
            this.input_07_06 = new System.Windows.Forms.TextBox();
            this.input_07_05 = new System.Windows.Forms.TextBox();
            this.input_07_04 = new System.Windows.Forms.TextBox();
            this.input_07_03 = new System.Windows.Forms.TextBox();
            this.input_07_02 = new System.Windows.Forms.TextBox();
            this.input_07_01 = new System.Windows.Forms.TextBox();
            this.input_07_00 = new System.Windows.Forms.TextBox();
            this.input_06_08 = new System.Windows.Forms.TextBox();
            this.input_06_07 = new System.Windows.Forms.TextBox();
            this.input_06_06 = new System.Windows.Forms.TextBox();
            this.input_06_05 = new System.Windows.Forms.TextBox();
            this.input_06_04 = new System.Windows.Forms.TextBox();
            this.input_06_03 = new System.Windows.Forms.TextBox();
            this.input_06_02 = new System.Windows.Forms.TextBox();
            this.input_06_01 = new System.Windows.Forms.TextBox();
            this.input_06_00 = new System.Windows.Forms.TextBox();
            this.input_05_08 = new System.Windows.Forms.TextBox();
            this.input_05_07 = new System.Windows.Forms.TextBox();
            this.input_05_06 = new System.Windows.Forms.TextBox();
            this.input_05_05 = new System.Windows.Forms.TextBox();
            this.input_05_04 = new System.Windows.Forms.TextBox();
            this.input_05_03 = new System.Windows.Forms.TextBox();
            this.input_05_02 = new System.Windows.Forms.TextBox();
            this.input_05_01 = new System.Windows.Forms.TextBox();
            this.input_05_00 = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.input_08_08 = new System.Windows.Forms.TextBox();
            this.input_08_07 = new System.Windows.Forms.TextBox();
            this.input_08_06 = new System.Windows.Forms.TextBox();
            this.input_08_05 = new System.Windows.Forms.TextBox();
            this.input_08_04 = new System.Windows.Forms.TextBox();
            this.input_08_03 = new System.Windows.Forms.TextBox();
            this.input_08_02 = new System.Windows.Forms.TextBox();
            this.input_08_01 = new System.Windows.Forms.TextBox();
            this.input_08_00 = new System.Windows.Forms.TextBox();
            this.btnTestLoad = new System.Windows.Forms.Button();
            this.txtIteractions = new System.Windows.Forms.TextBox();
            this.txtMode = new System.Windows.Forms.TextBox();
            this.btnEngine = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 20);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(237, 173);
            this.listBox1.TabIndex = 1;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(322, 20);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(213, 173);
            this.listBox2.TabIndex = 4;
            // 
            // input_00_00
            // 
            this.input_00_00.Location = new System.Drawing.Point(12, 203);
            this.input_00_00.Name = "input_00_00";
            this.input_00_00.Size = new System.Drawing.Size(21, 20);
            this.input_00_00.TabIndex = 5;
            // 
            // input_00_01
            // 
            this.input_00_01.Location = new System.Drawing.Point(39, 203);
            this.input_00_01.Name = "input_00_01";
            this.input_00_01.Size = new System.Drawing.Size(21, 20);
            this.input_00_01.TabIndex = 6;
            // 
            // input_00_02
            // 
            this.input_00_02.Location = new System.Drawing.Point(66, 203);
            this.input_00_02.Name = "input_00_02";
            this.input_00_02.Size = new System.Drawing.Size(21, 20);
            this.input_00_02.TabIndex = 7;
            // 
            // input_00_03
            // 
            this.input_00_03.Location = new System.Drawing.Point(93, 203);
            this.input_00_03.Name = "input_00_03";
            this.input_00_03.Size = new System.Drawing.Size(21, 20);
            this.input_00_03.TabIndex = 8;
            // 
            // input_00_04
            // 
            this.input_00_04.Location = new System.Drawing.Point(120, 203);
            this.input_00_04.Name = "input_00_04";
            this.input_00_04.Size = new System.Drawing.Size(21, 20);
            this.input_00_04.TabIndex = 9;
            // 
            // input_00_05
            // 
            this.input_00_05.Location = new System.Drawing.Point(147, 203);
            this.input_00_05.Name = "input_00_05";
            this.input_00_05.Size = new System.Drawing.Size(21, 20);
            this.input_00_05.TabIndex = 10;
            // 
            // input_00_06
            // 
            this.input_00_06.Location = new System.Drawing.Point(174, 203);
            this.input_00_06.Name = "input_00_06";
            this.input_00_06.Size = new System.Drawing.Size(21, 20);
            this.input_00_06.TabIndex = 11;
            // 
            // input_00_07
            // 
            this.input_00_07.Location = new System.Drawing.Point(201, 203);
            this.input_00_07.Name = "input_00_07";
            this.input_00_07.Size = new System.Drawing.Size(21, 20);
            this.input_00_07.TabIndex = 12;
            // 
            // input_00_08
            // 
            this.input_00_08.Location = new System.Drawing.Point(228, 203);
            this.input_00_08.Name = "input_00_08";
            this.input_00_08.Size = new System.Drawing.Size(21, 20);
            this.input_00_08.TabIndex = 13;
            // 
            // input_01_08
            // 
            this.input_01_08.Location = new System.Drawing.Point(228, 229);
            this.input_01_08.Name = "input_01_08";
            this.input_01_08.Size = new System.Drawing.Size(21, 20);
            this.input_01_08.TabIndex = 22;
            // 
            // input_01_07
            // 
            this.input_01_07.Location = new System.Drawing.Point(201, 229);
            this.input_01_07.Name = "input_01_07";
            this.input_01_07.Size = new System.Drawing.Size(21, 20);
            this.input_01_07.TabIndex = 21;
            // 
            // input_01_06
            // 
            this.input_01_06.Location = new System.Drawing.Point(174, 229);
            this.input_01_06.Name = "input_01_06";
            this.input_01_06.Size = new System.Drawing.Size(21, 20);
            this.input_01_06.TabIndex = 20;
            // 
            // input_01_05
            // 
            this.input_01_05.Location = new System.Drawing.Point(147, 229);
            this.input_01_05.Name = "input_01_05";
            this.input_01_05.Size = new System.Drawing.Size(21, 20);
            this.input_01_05.TabIndex = 19;
            // 
            // input_01_04
            // 
            this.input_01_04.Location = new System.Drawing.Point(120, 229);
            this.input_01_04.Name = "input_01_04";
            this.input_01_04.Size = new System.Drawing.Size(21, 20);
            this.input_01_04.TabIndex = 18;
            // 
            // input_01_03
            // 
            this.input_01_03.Location = new System.Drawing.Point(93, 229);
            this.input_01_03.Name = "input_01_03";
            this.input_01_03.Size = new System.Drawing.Size(21, 20);
            this.input_01_03.TabIndex = 17;
            // 
            // input_01_02
            // 
            this.input_01_02.Location = new System.Drawing.Point(66, 229);
            this.input_01_02.Name = "input_01_02";
            this.input_01_02.Size = new System.Drawing.Size(21, 20);
            this.input_01_02.TabIndex = 16;
            // 
            // input_01_01
            // 
            this.input_01_01.Location = new System.Drawing.Point(39, 229);
            this.input_01_01.Name = "input_01_01";
            this.input_01_01.Size = new System.Drawing.Size(21, 20);
            this.input_01_01.TabIndex = 15;
            // 
            // input_01_00
            // 
            this.input_01_00.Location = new System.Drawing.Point(12, 229);
            this.input_01_00.Name = "input_01_00";
            this.input_01_00.Size = new System.Drawing.Size(21, 20);
            this.input_01_00.TabIndex = 14;
            // 
            // input_02_08
            // 
            this.input_02_08.Location = new System.Drawing.Point(228, 255);
            this.input_02_08.Name = "input_02_08";
            this.input_02_08.Size = new System.Drawing.Size(21, 20);
            this.input_02_08.TabIndex = 31;
            // 
            // input_02_07
            // 
            this.input_02_07.Location = new System.Drawing.Point(201, 255);
            this.input_02_07.Name = "input_02_07";
            this.input_02_07.Size = new System.Drawing.Size(21, 20);
            this.input_02_07.TabIndex = 30;
            // 
            // input_02_06
            // 
            this.input_02_06.Location = new System.Drawing.Point(174, 255);
            this.input_02_06.Name = "input_02_06";
            this.input_02_06.Size = new System.Drawing.Size(21, 20);
            this.input_02_06.TabIndex = 29;
            // 
            // input_02_05
            // 
            this.input_02_05.Location = new System.Drawing.Point(147, 255);
            this.input_02_05.Name = "input_02_05";
            this.input_02_05.Size = new System.Drawing.Size(21, 20);
            this.input_02_05.TabIndex = 28;
            // 
            // input_02_04
            // 
            this.input_02_04.Location = new System.Drawing.Point(120, 255);
            this.input_02_04.Name = "input_02_04";
            this.input_02_04.Size = new System.Drawing.Size(21, 20);
            this.input_02_04.TabIndex = 27;
            // 
            // input_02_03
            // 
            this.input_02_03.Location = new System.Drawing.Point(93, 255);
            this.input_02_03.Name = "input_02_03";
            this.input_02_03.Size = new System.Drawing.Size(21, 20);
            this.input_02_03.TabIndex = 26;
            // 
            // input_02_02
            // 
            this.input_02_02.Location = new System.Drawing.Point(66, 255);
            this.input_02_02.Name = "input_02_02";
            this.input_02_02.Size = new System.Drawing.Size(21, 20);
            this.input_02_02.TabIndex = 25;
            // 
            // input_02_01
            // 
            this.input_02_01.Location = new System.Drawing.Point(39, 255);
            this.input_02_01.Name = "input_02_01";
            this.input_02_01.Size = new System.Drawing.Size(21, 20);
            this.input_02_01.TabIndex = 24;
            // 
            // input_02_00
            // 
            this.input_02_00.Location = new System.Drawing.Point(12, 255);
            this.input_02_00.Name = "input_02_00";
            this.input_02_00.Size = new System.Drawing.Size(21, 20);
            this.input_02_00.TabIndex = 23;
            // 
            // input_03_08
            // 
            this.input_03_08.Location = new System.Drawing.Point(228, 281);
            this.input_03_08.Name = "input_03_08";
            this.input_03_08.Size = new System.Drawing.Size(21, 20);
            this.input_03_08.TabIndex = 40;
            // 
            // input_03_07
            // 
            this.input_03_07.Location = new System.Drawing.Point(201, 281);
            this.input_03_07.Name = "input_03_07";
            this.input_03_07.Size = new System.Drawing.Size(21, 20);
            this.input_03_07.TabIndex = 39;
            // 
            // input_03_06
            // 
            this.input_03_06.Location = new System.Drawing.Point(174, 281);
            this.input_03_06.Name = "input_03_06";
            this.input_03_06.Size = new System.Drawing.Size(21, 20);
            this.input_03_06.TabIndex = 38;
            // 
            // input_03_05
            // 
            this.input_03_05.Location = new System.Drawing.Point(147, 281);
            this.input_03_05.Name = "input_03_05";
            this.input_03_05.Size = new System.Drawing.Size(21, 20);
            this.input_03_05.TabIndex = 37;
            // 
            // input_03_04
            // 
            this.input_03_04.Location = new System.Drawing.Point(120, 281);
            this.input_03_04.Name = "input_03_04";
            this.input_03_04.Size = new System.Drawing.Size(21, 20);
            this.input_03_04.TabIndex = 36;
            // 
            // input_03_03
            // 
            this.input_03_03.Location = new System.Drawing.Point(93, 281);
            this.input_03_03.Name = "input_03_03";
            this.input_03_03.Size = new System.Drawing.Size(21, 20);
            this.input_03_03.TabIndex = 35;
            // 
            // input_03_02
            // 
            this.input_03_02.Location = new System.Drawing.Point(66, 281);
            this.input_03_02.Name = "input_03_02";
            this.input_03_02.Size = new System.Drawing.Size(21, 20);
            this.input_03_02.TabIndex = 34;
            // 
            // input_03_01
            // 
            this.input_03_01.Location = new System.Drawing.Point(39, 281);
            this.input_03_01.Name = "input_03_01";
            this.input_03_01.Size = new System.Drawing.Size(21, 20);
            this.input_03_01.TabIndex = 33;
            // 
            // input_03_00
            // 
            this.input_03_00.Location = new System.Drawing.Point(12, 281);
            this.input_03_00.Name = "input_03_00";
            this.input_03_00.Size = new System.Drawing.Size(21, 20);
            this.input_03_00.TabIndex = 32;
            // 
            // input_04_08
            // 
            this.input_04_08.Location = new System.Drawing.Point(228, 307);
            this.input_04_08.Name = "input_04_08";
            this.input_04_08.Size = new System.Drawing.Size(21, 20);
            this.input_04_08.TabIndex = 49;
            // 
            // input_04_07
            // 
            this.input_04_07.Location = new System.Drawing.Point(201, 307);
            this.input_04_07.Name = "input_04_07";
            this.input_04_07.Size = new System.Drawing.Size(21, 20);
            this.input_04_07.TabIndex = 48;
            // 
            // input_04_06
            // 
            this.input_04_06.Location = new System.Drawing.Point(174, 307);
            this.input_04_06.Name = "input_04_06";
            this.input_04_06.Size = new System.Drawing.Size(21, 20);
            this.input_04_06.TabIndex = 47;
            // 
            // input_04_05
            // 
            this.input_04_05.Location = new System.Drawing.Point(147, 307);
            this.input_04_05.Name = "input_04_05";
            this.input_04_05.Size = new System.Drawing.Size(21, 20);
            this.input_04_05.TabIndex = 46;
            // 
            // input_04_04
            // 
            this.input_04_04.Location = new System.Drawing.Point(120, 307);
            this.input_04_04.Name = "input_04_04";
            this.input_04_04.Size = new System.Drawing.Size(21, 20);
            this.input_04_04.TabIndex = 45;
            // 
            // input_04_03
            // 
            this.input_04_03.Location = new System.Drawing.Point(93, 307);
            this.input_04_03.Name = "input_04_03";
            this.input_04_03.Size = new System.Drawing.Size(21, 20);
            this.input_04_03.TabIndex = 44;
            // 
            // input_04_02
            // 
            this.input_04_02.Location = new System.Drawing.Point(66, 307);
            this.input_04_02.Name = "input_04_02";
            this.input_04_02.Size = new System.Drawing.Size(21, 20);
            this.input_04_02.TabIndex = 43;
            // 
            // input_04_01
            // 
            this.input_04_01.Location = new System.Drawing.Point(39, 307);
            this.input_04_01.Name = "input_04_01";
            this.input_04_01.Size = new System.Drawing.Size(21, 20);
            this.input_04_01.TabIndex = 42;
            // 
            // input_04_00
            // 
            this.input_04_00.Location = new System.Drawing.Point(12, 307);
            this.input_04_00.Name = "input_04_00";
            this.input_04_00.Size = new System.Drawing.Size(21, 20);
            this.input_04_00.TabIndex = 41;
            // 
            // input_07_08
            // 
            this.input_07_08.Location = new System.Drawing.Point(228, 385);
            this.input_07_08.Name = "input_07_08";
            this.input_07_08.Size = new System.Drawing.Size(21, 20);
            this.input_07_08.TabIndex = 76;
            // 
            // input_07_07
            // 
            this.input_07_07.Location = new System.Drawing.Point(201, 385);
            this.input_07_07.Name = "input_07_07";
            this.input_07_07.Size = new System.Drawing.Size(21, 20);
            this.input_07_07.TabIndex = 75;
            // 
            // input_07_06
            // 
            this.input_07_06.Location = new System.Drawing.Point(174, 385);
            this.input_07_06.Name = "input_07_06";
            this.input_07_06.Size = new System.Drawing.Size(21, 20);
            this.input_07_06.TabIndex = 74;
            // 
            // input_07_05
            // 
            this.input_07_05.Location = new System.Drawing.Point(147, 385);
            this.input_07_05.Name = "input_07_05";
            this.input_07_05.Size = new System.Drawing.Size(21, 20);
            this.input_07_05.TabIndex = 73;
            // 
            // input_07_04
            // 
            this.input_07_04.Location = new System.Drawing.Point(120, 385);
            this.input_07_04.Name = "input_07_04";
            this.input_07_04.Size = new System.Drawing.Size(21, 20);
            this.input_07_04.TabIndex = 72;
            // 
            // input_07_03
            // 
            this.input_07_03.Location = new System.Drawing.Point(93, 385);
            this.input_07_03.Name = "input_07_03";
            this.input_07_03.Size = new System.Drawing.Size(21, 20);
            this.input_07_03.TabIndex = 71;
            // 
            // input_07_02
            // 
            this.input_07_02.Location = new System.Drawing.Point(66, 385);
            this.input_07_02.Name = "input_07_02";
            this.input_07_02.Size = new System.Drawing.Size(21, 20);
            this.input_07_02.TabIndex = 70;
            // 
            // input_07_01
            // 
            this.input_07_01.Location = new System.Drawing.Point(39, 385);
            this.input_07_01.Name = "input_07_01";
            this.input_07_01.Size = new System.Drawing.Size(21, 20);
            this.input_07_01.TabIndex = 69;
            // 
            // input_07_00
            // 
            this.input_07_00.Location = new System.Drawing.Point(12, 385);
            this.input_07_00.Name = "input_07_00";
            this.input_07_00.Size = new System.Drawing.Size(21, 20);
            this.input_07_00.TabIndex = 68;
            // 
            // input_06_08
            // 
            this.input_06_08.Location = new System.Drawing.Point(228, 359);
            this.input_06_08.Name = "input_06_08";
            this.input_06_08.Size = new System.Drawing.Size(21, 20);
            this.input_06_08.TabIndex = 67;
            // 
            // input_06_07
            // 
            this.input_06_07.Location = new System.Drawing.Point(201, 359);
            this.input_06_07.Name = "input_06_07";
            this.input_06_07.Size = new System.Drawing.Size(21, 20);
            this.input_06_07.TabIndex = 66;
            // 
            // input_06_06
            // 
            this.input_06_06.Location = new System.Drawing.Point(174, 359);
            this.input_06_06.Name = "input_06_06";
            this.input_06_06.Size = new System.Drawing.Size(21, 20);
            this.input_06_06.TabIndex = 65;
            // 
            // input_06_05
            // 
            this.input_06_05.Location = new System.Drawing.Point(147, 359);
            this.input_06_05.Name = "input_06_05";
            this.input_06_05.Size = new System.Drawing.Size(21, 20);
            this.input_06_05.TabIndex = 64;
            // 
            // input_06_04
            // 
            this.input_06_04.Location = new System.Drawing.Point(120, 359);
            this.input_06_04.Name = "input_06_04";
            this.input_06_04.Size = new System.Drawing.Size(21, 20);
            this.input_06_04.TabIndex = 63;
            // 
            // input_06_03
            // 
            this.input_06_03.Location = new System.Drawing.Point(93, 359);
            this.input_06_03.Name = "input_06_03";
            this.input_06_03.Size = new System.Drawing.Size(21, 20);
            this.input_06_03.TabIndex = 62;
            // 
            // input_06_02
            // 
            this.input_06_02.Location = new System.Drawing.Point(66, 359);
            this.input_06_02.Name = "input_06_02";
            this.input_06_02.Size = new System.Drawing.Size(21, 20);
            this.input_06_02.TabIndex = 61;
            // 
            // input_06_01
            // 
            this.input_06_01.Location = new System.Drawing.Point(39, 359);
            this.input_06_01.Name = "input_06_01";
            this.input_06_01.Size = new System.Drawing.Size(21, 20);
            this.input_06_01.TabIndex = 60;
            // 
            // input_06_00
            // 
            this.input_06_00.Location = new System.Drawing.Point(12, 359);
            this.input_06_00.Name = "input_06_00";
            this.input_06_00.Size = new System.Drawing.Size(21, 20);
            this.input_06_00.TabIndex = 59;
            // 
            // input_05_08
            // 
            this.input_05_08.Location = new System.Drawing.Point(228, 333);
            this.input_05_08.Name = "input_05_08";
            this.input_05_08.Size = new System.Drawing.Size(21, 20);
            this.input_05_08.TabIndex = 58;
            // 
            // input_05_07
            // 
            this.input_05_07.Location = new System.Drawing.Point(201, 333);
            this.input_05_07.Name = "input_05_07";
            this.input_05_07.Size = new System.Drawing.Size(21, 20);
            this.input_05_07.TabIndex = 57;
            // 
            // input_05_06
            // 
            this.input_05_06.Location = new System.Drawing.Point(174, 333);
            this.input_05_06.Name = "input_05_06";
            this.input_05_06.Size = new System.Drawing.Size(21, 20);
            this.input_05_06.TabIndex = 56;
            // 
            // input_05_05
            // 
            this.input_05_05.Location = new System.Drawing.Point(147, 333);
            this.input_05_05.Name = "input_05_05";
            this.input_05_05.Size = new System.Drawing.Size(21, 20);
            this.input_05_05.TabIndex = 55;
            // 
            // input_05_04
            // 
            this.input_05_04.Location = new System.Drawing.Point(120, 333);
            this.input_05_04.Name = "input_05_04";
            this.input_05_04.Size = new System.Drawing.Size(21, 20);
            this.input_05_04.TabIndex = 54;
            // 
            // input_05_03
            // 
            this.input_05_03.Location = new System.Drawing.Point(93, 333);
            this.input_05_03.Name = "input_05_03";
            this.input_05_03.Size = new System.Drawing.Size(21, 20);
            this.input_05_03.TabIndex = 53;
            // 
            // input_05_02
            // 
            this.input_05_02.Location = new System.Drawing.Point(66, 333);
            this.input_05_02.Name = "input_05_02";
            this.input_05_02.Size = new System.Drawing.Size(21, 20);
            this.input_05_02.TabIndex = 52;
            // 
            // input_05_01
            // 
            this.input_05_01.Location = new System.Drawing.Point(39, 333);
            this.input_05_01.Name = "input_05_01";
            this.input_05_01.Size = new System.Drawing.Size(21, 20);
            this.input_05_01.TabIndex = 51;
            // 
            // input_05_00
            // 
            this.input_05_00.Location = new System.Drawing.Point(12, 333);
            this.input_05_00.Name = "input_05_00";
            this.input_05_00.Size = new System.Drawing.Size(21, 20);
            this.input_05_00.TabIndex = 50;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(255, 295);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 50);
            this.btnLoad.TabIndex = 86;
            this.btnLoad.Text = "Load User Data";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // input_08_08
            // 
            this.input_08_08.Location = new System.Drawing.Point(228, 411);
            this.input_08_08.Name = "input_08_08";
            this.input_08_08.Size = new System.Drawing.Size(21, 20);
            this.input_08_08.TabIndex = 85;
            // 
            // input_08_07
            // 
            this.input_08_07.Location = new System.Drawing.Point(201, 411);
            this.input_08_07.Name = "input_08_07";
            this.input_08_07.Size = new System.Drawing.Size(21, 20);
            this.input_08_07.TabIndex = 84;
            // 
            // input_08_06
            // 
            this.input_08_06.Location = new System.Drawing.Point(174, 411);
            this.input_08_06.Name = "input_08_06";
            this.input_08_06.Size = new System.Drawing.Size(21, 20);
            this.input_08_06.TabIndex = 83;
            // 
            // input_08_05
            // 
            this.input_08_05.Location = new System.Drawing.Point(147, 411);
            this.input_08_05.Name = "input_08_05";
            this.input_08_05.Size = new System.Drawing.Size(21, 20);
            this.input_08_05.TabIndex = 82;
            // 
            // input_08_04
            // 
            this.input_08_04.Location = new System.Drawing.Point(120, 411);
            this.input_08_04.Name = "input_08_04";
            this.input_08_04.Size = new System.Drawing.Size(21, 20);
            this.input_08_04.TabIndex = 81;
            // 
            // input_08_03
            // 
            this.input_08_03.Location = new System.Drawing.Point(93, 411);
            this.input_08_03.Name = "input_08_03";
            this.input_08_03.Size = new System.Drawing.Size(21, 20);
            this.input_08_03.TabIndex = 80;
            // 
            // input_08_02
            // 
            this.input_08_02.Location = new System.Drawing.Point(66, 411);
            this.input_08_02.Name = "input_08_02";
            this.input_08_02.Size = new System.Drawing.Size(21, 20);
            this.input_08_02.TabIndex = 79;
            // 
            // input_08_01
            // 
            this.input_08_01.Location = new System.Drawing.Point(39, 411);
            this.input_08_01.Name = "input_08_01";
            this.input_08_01.Size = new System.Drawing.Size(21, 20);
            this.input_08_01.TabIndex = 78;
            // 
            // input_08_00
            // 
            this.input_08_00.Location = new System.Drawing.Point(12, 411);
            this.input_08_00.Name = "input_08_00";
            this.input_08_00.Size = new System.Drawing.Size(21, 20);
            this.input_08_00.TabIndex = 77;
            // 
            // btnTestLoad
            // 
            this.btnTestLoad.Location = new System.Drawing.Point(255, 135);
            this.btnTestLoad.Name = "btnTestLoad";
            this.btnTestLoad.Size = new System.Drawing.Size(61, 43);
            this.btnTestLoad.TabIndex = 87;
            this.btnTestLoad.Text = "Load Test";
            this.btnTestLoad.UseVisualStyleBackColor = true;
            this.btnTestLoad.Click += new System.EventHandler(this.btnTestLoad_Click);
            // 
            // txtIteractions
            // 
            this.txtIteractions.Location = new System.Drawing.Point(472, 229);
            this.txtIteractions.Name = "txtIteractions";
            this.txtIteractions.Size = new System.Drawing.Size(137, 20);
            this.txtIteractions.TabIndex = 88;
            // 
            // txtMode
            // 
            this.txtMode.Location = new System.Drawing.Point(472, 255);
            this.txtMode.Name = "txtMode";
            this.txtMode.Size = new System.Drawing.Size(100, 20);
            this.txtMode.TabIndex = 89;
            // 
            // btnEngine
            // 
            this.btnEngine.Location = new System.Drawing.Point(255, 85);
            this.btnEngine.Name = "btnEngine";
            this.btnEngine.Size = new System.Drawing.Size(61, 23);
            this.btnEngine.TabIndex = 90;
            this.btnEngine.Text = "Engine";
            this.btnEngine.UseVisualStyleBackColor = true;
            this.btnEngine.Click += new System.EventHandler(this.btnEngine_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 91;
            this.label1.Text = "Before";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(319, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 92;
            this.label2.Text = "Solution";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 443);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnEngine);
            this.Controls.Add(this.txtMode);
            this.Controls.Add(this.txtIteractions);
            this.Controls.Add(this.btnTestLoad);
            this.Controls.Add(this.input_08_08);
            this.Controls.Add(this.input_08_07);
            this.Controls.Add(this.input_08_06);
            this.Controls.Add(this.input_08_05);
            this.Controls.Add(this.input_08_04);
            this.Controls.Add(this.input_08_03);
            this.Controls.Add(this.input_08_02);
            this.Controls.Add(this.input_08_01);
            this.Controls.Add(this.input_08_00);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.input_07_08);
            this.Controls.Add(this.input_07_07);
            this.Controls.Add(this.input_07_06);
            this.Controls.Add(this.input_07_05);
            this.Controls.Add(this.input_07_04);
            this.Controls.Add(this.input_07_03);
            this.Controls.Add(this.input_07_02);
            this.Controls.Add(this.input_07_01);
            this.Controls.Add(this.input_07_00);
            this.Controls.Add(this.input_06_08);
            this.Controls.Add(this.input_06_07);
            this.Controls.Add(this.input_06_06);
            this.Controls.Add(this.input_06_05);
            this.Controls.Add(this.input_06_04);
            this.Controls.Add(this.input_06_03);
            this.Controls.Add(this.input_06_02);
            this.Controls.Add(this.input_06_01);
            this.Controls.Add(this.input_06_00);
            this.Controls.Add(this.input_05_08);
            this.Controls.Add(this.input_05_07);
            this.Controls.Add(this.input_05_06);
            this.Controls.Add(this.input_05_05);
            this.Controls.Add(this.input_05_04);
            this.Controls.Add(this.input_05_03);
            this.Controls.Add(this.input_05_02);
            this.Controls.Add(this.input_05_01);
            this.Controls.Add(this.input_05_00);
            this.Controls.Add(this.input_04_08);
            this.Controls.Add(this.input_04_07);
            this.Controls.Add(this.input_04_06);
            this.Controls.Add(this.input_04_05);
            this.Controls.Add(this.input_04_04);
            this.Controls.Add(this.input_04_03);
            this.Controls.Add(this.input_04_02);
            this.Controls.Add(this.input_04_01);
            this.Controls.Add(this.input_04_00);
            this.Controls.Add(this.input_03_08);
            this.Controls.Add(this.input_03_07);
            this.Controls.Add(this.input_03_06);
            this.Controls.Add(this.input_03_05);
            this.Controls.Add(this.input_03_04);
            this.Controls.Add(this.input_03_03);
            this.Controls.Add(this.input_03_02);
            this.Controls.Add(this.input_03_01);
            this.Controls.Add(this.input_03_00);
            this.Controls.Add(this.input_02_08);
            this.Controls.Add(this.input_02_07);
            this.Controls.Add(this.input_02_06);
            this.Controls.Add(this.input_02_05);
            this.Controls.Add(this.input_02_04);
            this.Controls.Add(this.input_02_03);
            this.Controls.Add(this.input_02_02);
            this.Controls.Add(this.input_02_01);
            this.Controls.Add(this.input_02_00);
            this.Controls.Add(this.input_01_08);
            this.Controls.Add(this.input_01_07);
            this.Controls.Add(this.input_01_06);
            this.Controls.Add(this.input_01_05);
            this.Controls.Add(this.input_01_04);
            this.Controls.Add(this.input_01_03);
            this.Controls.Add(this.input_01_02);
            this.Controls.Add(this.input_01_01);
            this.Controls.Add(this.input_01_00);
            this.Controls.Add(this.input_00_08);
            this.Controls.Add(this.input_00_07);
            this.Controls.Add(this.input_00_06);
            this.Controls.Add(this.input_00_05);
            this.Controls.Add(this.input_00_04);
            this.Controls.Add(this.input_00_03);
            this.Controls.Add(this.input_00_02);
            this.Controls.Add(this.input_00_01);
            this.Controls.Add(this.input_00_00);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Sudoku by Dan";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox input_00_00;
        private System.Windows.Forms.TextBox input_00_01;
        private System.Windows.Forms.TextBox input_00_02;
        private System.Windows.Forms.TextBox input_00_03;
        private System.Windows.Forms.TextBox input_00_04;
        private System.Windows.Forms.TextBox input_00_05;
        private System.Windows.Forms.TextBox input_00_06;
        private System.Windows.Forms.TextBox input_00_07;
        private System.Windows.Forms.TextBox input_00_08;
        private System.Windows.Forms.TextBox input_01_08;
        private System.Windows.Forms.TextBox input_01_07;
        private System.Windows.Forms.TextBox input_01_06;
        private System.Windows.Forms.TextBox input_01_05;
        private System.Windows.Forms.TextBox input_01_04;
        private System.Windows.Forms.TextBox input_01_03;
        private System.Windows.Forms.TextBox input_01_02;
        private System.Windows.Forms.TextBox input_01_01;
        private System.Windows.Forms.TextBox input_01_00;
        private System.Windows.Forms.TextBox input_02_08;
        private System.Windows.Forms.TextBox input_02_07;
        private System.Windows.Forms.TextBox input_02_06;
        private System.Windows.Forms.TextBox input_02_05;
        private System.Windows.Forms.TextBox input_02_04;
        private System.Windows.Forms.TextBox input_02_03;
        private System.Windows.Forms.TextBox input_02_02;
        private System.Windows.Forms.TextBox input_02_01;
        private System.Windows.Forms.TextBox input_02_00;
        private System.Windows.Forms.TextBox input_03_08;
        private System.Windows.Forms.TextBox input_03_07;
        private System.Windows.Forms.TextBox input_03_06;
        private System.Windows.Forms.TextBox input_03_05;
        private System.Windows.Forms.TextBox input_03_04;
        private System.Windows.Forms.TextBox input_03_03;
        private System.Windows.Forms.TextBox input_03_02;
        private System.Windows.Forms.TextBox input_03_01;
        private System.Windows.Forms.TextBox input_03_00;
        private System.Windows.Forms.TextBox input_04_08;
        private System.Windows.Forms.TextBox input_04_07;
        private System.Windows.Forms.TextBox input_04_06;
        private System.Windows.Forms.TextBox input_04_05;
        private System.Windows.Forms.TextBox input_04_04;
        private System.Windows.Forms.TextBox input_04_03;
        private System.Windows.Forms.TextBox input_04_02;
        private System.Windows.Forms.TextBox input_04_01;
        private System.Windows.Forms.TextBox input_04_00;
        private System.Windows.Forms.TextBox input_07_08;
        private System.Windows.Forms.TextBox input_07_07;
        private System.Windows.Forms.TextBox input_07_06;
        private System.Windows.Forms.TextBox input_07_05;
        private System.Windows.Forms.TextBox input_07_04;
        private System.Windows.Forms.TextBox input_07_03;
        private System.Windows.Forms.TextBox input_07_02;
        private System.Windows.Forms.TextBox input_07_01;
        private System.Windows.Forms.TextBox input_07_00;
        private System.Windows.Forms.TextBox input_06_08;
        private System.Windows.Forms.TextBox input_06_07;
        private System.Windows.Forms.TextBox input_06_06;
        private System.Windows.Forms.TextBox input_06_05;
        private System.Windows.Forms.TextBox input_06_04;
        private System.Windows.Forms.TextBox input_06_03;
        private System.Windows.Forms.TextBox input_06_02;
        private System.Windows.Forms.TextBox input_06_01;
        private System.Windows.Forms.TextBox input_06_00;
        private System.Windows.Forms.TextBox input_05_08;
        private System.Windows.Forms.TextBox input_05_07;
        private System.Windows.Forms.TextBox input_05_06;
        private System.Windows.Forms.TextBox input_05_05;
        private System.Windows.Forms.TextBox input_05_04;
        private System.Windows.Forms.TextBox input_05_03;
        private System.Windows.Forms.TextBox input_05_02;
        private System.Windows.Forms.TextBox input_05_01;
        private System.Windows.Forms.TextBox input_05_00;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.TextBox input_08_08;
        private System.Windows.Forms.TextBox input_08_07;
        private System.Windows.Forms.TextBox input_08_06;
        private System.Windows.Forms.TextBox input_08_05;
        private System.Windows.Forms.TextBox input_08_04;
        private System.Windows.Forms.TextBox input_08_03;
        private System.Windows.Forms.TextBox input_08_02;
        private System.Windows.Forms.TextBox input_08_01;
        private System.Windows.Forms.TextBox input_08_00;
        private System.Windows.Forms.Button btnTestLoad;
        private System.Windows.Forms.TextBox txtIteractions;
        private System.Windows.Forms.TextBox txtMode;
        private System.Windows.Forms.Button btnEngine;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

